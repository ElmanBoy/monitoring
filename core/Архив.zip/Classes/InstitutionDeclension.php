<?php


namespace Core;


class InstitutionDeclension
{

    private static $nounExceptions = [
        'учреждение' => [
            'genitive' => 'учреждения',
            'dative' => 'учреждению',
            'accusative' => 'учреждение',
            'instrumental' => 'учреждением',
            'prepositional' => 'учреждении'
        ],
        'пансионат' => [
            'genitive' => 'пансионата',
            'dative' => 'пансионату',
            'accusative' => 'пансионат',
            'instrumental' => 'пансионатом',
            'prepositional' => 'пансионате'
        ]
    ];

    private static $adjectiveExceptions = [
        'Государственное' => [
            'genitive' => 'Государственного',
            'dative' => 'Государственному',
            'accusative' => 'Государственное',
            'instrumental' => 'Государственным',
            'prepositional' => 'Государственном'
        ],
        'бюджетное' => [
            'genitive' => 'бюджетного',
            'dative' => 'бюджетному',
            'accusative' => 'бюджетное',
            'instrumental' => 'бюджетным',
            'prepositional' => 'бюджетном'
        ],
        'стационарное' => [
            'genitive' => 'стационарного',
            'dative' => 'стационарному',
            'accusative' => 'стационарное',
            'instrumental' => 'стационарным',
            'prepositional' => 'стационарном'
        ]
    ];

    private static $fixedForms = [
        'социального' => 'социального',
        'обслуживания' => 'обслуживания',
        'Московской' => 'Московской',
        'области' => 'области'
    ];

    public static function decline($name, $case)
    {
        // Сначала декодируем HTML-сущности, если они есть
        $decodedName = html_entity_decode($name, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Теперь ищем кавычки в декодированной строке
        return self::processDeclension($decodedName, $case);
    }

    private static function processDeclension($name, $case)
    {
        // Ищем любые виды кавычек: " , «, », &quot; (но они уже декодированы)
        $quotePos = self::findFirstQuote($name);

        if ($quotePos === false) {
            // Нет кавычек - склоняем всё
            return self::declinePrefix($name, $case);
        }

        // Всё, что до кавычек - склоняем
        $prefix = mb_substr($name, 0, $quotePos);
        // Всё, что после (включая кавычки) - оставляем как есть
        $quoted = mb_substr($name, $quotePos);

        $declinedPrefix = self::declinePrefix($prefix, $case);

        return $declinedPrefix . ' '. $quoted;
    }

    /**
     * Поиск первой кавычки с учётом разных типов
     */
    private static function findFirstQuote($text)
    {
        $quoteChars = ['"', '«', '»', '&quot;']; // &quot; на случай если не декодировалось

        $firstPos = false;
        foreach ($quoteChars as $quote) {
            $pos = mb_strpos($text, $quote);
            if ($pos !== false && ($firstPos === false || $pos < $firstPos)) {
                $firstPos = $pos;
            }
        }

        return $firstPos;
    }

    private static function declinePrefix($prefix, $case)
    {
        $words = preg_split('/\s+/u', trim($prefix));
        $result = [];

        foreach ($words as $word) {
            if (empty($word)) continue;

            if (self::isPreposition($word)) {
                $result[] = $word;
                continue;
            }

            if (isset(self::$fixedForms[$word])) {
                $result[] = $word;
                continue;
            }

            if (isset(self::$adjectiveExceptions[$word]) && isset(self::$adjectiveExceptions[$word][$case])) {
                $result[] = self::$adjectiveExceptions[$word][$case];
                continue;
            }

            $found = false;
            foreach (self::$nounExceptions as $base => $forms) {
                if (mb_strtolower($word) === mb_strtolower($base)) {
                    if (isset($forms[$case])) {
                        $result[] = $forms[$case];
                        $found = true;
                        break;
                    }
                }
            }

            if ($found) {
                continue;
            }

            $result[] = self::declineByRules($word, $case);
        }

        return implode(' ', $result);
    }

    private static function declineByRules($word, $case)
    {
        if ($case == 'nominative') {
            return $word;
        }

        if (self::isAdjective($word)) {
            return self::declineAdjective($word, $case);
        }

        return self::declineNoun($word, $case);
    }

    private static function declineAdjective($word, $case)
    {
        $endings = [
            'ое' => ['genitive' => 'ого', 'dative' => 'ому', 'accusative' => 'ое', 'instrumental' => 'ым', 'prepositional' => 'ом'],
            'ая' => ['genitive' => 'ой', 'dative' => 'ой', 'accusative' => 'ую', 'instrumental' => 'ой', 'prepositional' => 'ой'],
            'яя' => ['genitive' => 'ей', 'dative' => 'ей', 'accusative' => 'юю', 'instrumental' => 'ей', 'prepositional' => 'ей'],
            'ый' => ['genitive' => 'ого', 'dative' => 'ому', 'accusative' => 'ый', 'instrumental' => 'ым', 'prepositional' => 'ом'],
            'ий' => ['genitive' => 'его', 'dative' => 'ему', 'accusative' => 'ий', 'instrumental' => 'им', 'prepositional' => 'ем']
        ];

        foreach ($endings as $ending => $caseEndings) {
            if (mb_substr($word, -mb_strlen($ending)) == $ending) {
                $base = mb_substr($word, 0, -mb_strlen($ending));
                if (isset($caseEndings[$case])) {
                    return $base . $caseEndings[$case];
                }
            }
        }

        return $word;
    }

    private static function declineNoun($word, $case)
    {
        $lastChar = mb_substr($word, -1);

        if (preg_match('/[бвгджзйклмнпрстфхцчшщ]$/u', $lastChar)) {
            $endings = [
                'genitive' => 'а',
                'dative' => 'у',
                'accusative' => $word,
                'instrumental' => 'ом',
                'prepositional' => 'е'
            ];
            return isset($endings[$case]) ? $word . $endings[$case] : $word;
        }

        if ($lastChar == 'о' || $lastChar == 'е') {
            $base = mb_substr($word, 0, -1);
            $endings = [
                'genitive' => 'а',
                'dative' => 'у',
                'accusative' => $word,
                'instrumental' => 'ом',
                'prepositional' => 'е'
            ];
            return isset($endings[$case]) ? $base . $endings[$case] : $word;
        }

        if ($lastChar == 'а') {
            $base = mb_substr($word, 0, -1);
            $endings = [
                'genitive' => 'ы',
                'dative' => 'е',
                'accusative' => 'у',
                'instrumental' => 'ой',
                'prepositional' => 'е'
            ];
            return isset($endings[$case]) ? $base . $endings[$case] : $word;
        }

        return $word;
    }

    private static function isAdjective($word)
    {
        $endings = ['ый', 'ий', 'ой', 'ая', 'яя', 'ое', 'ее', 'ые', 'ие'];
        foreach ($endings as $ending) {
            if (mb_substr($word, -mb_strlen($ending)) == $ending) {
                return true;
            }
        }
        return false;
    }

    private static function isPreposition($word)
    {
        $prepositions = ['в', 'на', 'по', 'из', 'от', 'для', 'с', 'у', 'о', 'об', 'без', 'до', 'при'];
        return in_array(mb_strtolower($word), $prepositions);
    }
}
/*
// ТЕСТ С РАЗНЫМИ СЦЕНАРИЯМИ
echo "=== ТЕСТ 1: БЕЗ HTMLSPECIALCHARS ===\n";
$name = 'Государственное бюджетное стационарное учреждение социального обслуживания Московской области "Пансионат "Клинский""';
echo 'Оригинал:      ' . $name . "\n";
echo 'Родительный:   ' . InstitutionDeclension::decline($name, 'genitive') . "\n";

echo "\n=== ТЕСТ 2: С HTMLSPECIALCHARS (как в вашем коде) ===\n";
$encodedName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
echo "После htmlspecialchars:\n" . $encodedName . "\n\n";
echo "Родительный после декодирования:\n" . InstitutionDeclension::decline($encodedName, 'genitive') . "\n";

echo "\n=== ТЕСТ 3: С ДРУГИМ ТИПОМ КАВЫЧЕК ===\n";
$name2 = 'Государственное бюджетное учреждение социального обслуживания Московской области «Комплексный центр социального обслуживания и реабилитации «Раменский»';
echo 'Оригинал:      ' . $name2 . "\n";
echo 'Родительный:   ' . InstitutionDeclension::decline($name2, 'genitive') . "\n";
*/
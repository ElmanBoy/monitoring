<?php


namespace Core;


class PositionDeclension
{
    private static $positionExceptions = [
        'министр' => [
            'genitive' => 'министра',
            'dative' => 'министру',
            'accusative' => 'министра',
            'instrumental' => 'министром',
            'prepositional' => 'министре'
        ],
        'заместитель' => [
            'genitive' => 'заместителя',
            'dative' => 'заместителю',
            'accusative' => 'заместителя',
            'instrumental' => 'заместителем',
            'prepositional' => 'заместителе'
        ],
        'первый заместитель' => [
            'genitive' => 'первого заместителя',
            'dative' => 'первому заместителю',
            'accusative' => 'первого заместителя',
            'instrumental' => 'первым заместителем',
            'prepositional' => 'первом заместителе'
        ],
        'начальник' => [
            'genitive' => 'начальника',
            'dative' => 'начальнику',
            'accusative' => 'начальника',
            'instrumental' => 'начальником',
            'prepositional' => 'начальнике'
        ],
        'заведующий' => [
            'genitive' => 'заведующего',
            'dative' => 'заведующему',
            'accusative' => 'заведующего',
            'instrumental' => 'заведующим',
            'prepositional' => 'заведующем'
        ],
        'директор' => [
            'genitive' => 'директора',
            'dative' => 'директору',
            'accusative' => 'директора',
            'instrumental' => 'директором',
            'prepositional' => 'директоре'
        ],
        'главный специалист' => [
            'genitive' => 'главного специалиста',
            'dative' => 'главному специалисту',
            'accusative' => 'главного специалиста',
            'instrumental' => 'главным специалистом',
            'prepositional' => 'главном специалисте'
        ],
        'специалист' => [
            'genitive' => 'специалиста',
            'dative' => 'специалисту',
            'accusative' => 'специалиста',
            'instrumental' => 'специалистом',
            'prepositional' => 'специалисте'
        ],
        'инспектор' => [
            'genitive' => 'инспектора',
            'dative' => 'инспектору',
            'accusative' => 'инспектора',
            'instrumental' => 'инспектором',
            'prepositional' => 'инспекторе'
        ],
        'консультант' => [
            'genitive' => 'консультанта',
            'dative' => 'консультанту',
            'accusative' => 'консультанта',
            'instrumental' => 'консультантом',
            'prepositional' => 'консультанте'
        ],
        'советник' => [
            'genitive' => 'советника',
            'dative' => 'советнику',
            'accusative' => 'советника',
            'instrumental' => 'советником',
            'prepositional' => 'советнике'
        ],
        'разработчик' => [
            'genitive' => 'разработчика',
            'dative' => 'разработчику',
            'accusative' => 'разработчика',
            'instrumental' => 'разработчиком',
            'prepositional' => 'разработчике'
        ],
        'губернатор' => [
            'genitive' => 'губернатора',
            'dative' => 'губернатору',
            'accusative' => 'губернатора',
            'instrumental' => 'губернатором',
            'prepositional' => 'губернаторе'
        ],
        'отдел' => [
            'genitive' => 'отдела',
            'dative' => 'отделу',
            'accusative' => 'отдел',
            'instrumental' => 'отделом',
            'prepositional' => 'отделе'
        ],
        'управление' => [
            'genitive' => 'управления',
            'dative' => 'управлению',
            'accusative' => 'управление',
            'instrumental' => 'управлением',
            'prepositional' => 'управлении'
        ],
        'министерство' => [
            'genitive' => 'министерства',
            'dative' => 'министерству',
            'accusative' => 'министерство',
            'instrumental' => 'министерством',
            'prepositional' => 'министерстве'
        ]
    ];

    private static $governmentRules = [
        'заведующий' => 'instrumental',
        'начальник' => 'genitive',
        'директор' => 'genitive',
        'заместитель' => 'genitive',
        'министр' => 'genitive',
    ];

    private static $fixedWords = ['врио', 'ВРИО', 'и.о.', 'И.О.'];

    private static $fixedPhrases = [
        'социального развития',
        'Московской области',
        'Правительства Московской области',
        'финансового контроля и аудита',
        'мониторинга и сводного анализа',
        'обеспечения контрольных функций',
        'внутреннего финансового аудита',
        'финансового контроля',
        'контрольных функций',
        'внутреннего аудита',
        'финансового менеджмента'
    ];

    public static function decline($position, $case, $gender = 'male')
    {
        $position = trim($position);
        if (empty($position)) return '';

        if (strpos($position, 'Тестовый') !== false || $position === 'Сотрудниковская') {
            return $position;
        }

        if (preg_match('/^(ВРИО|врио)\s+(.+)$/u', $position, $matches)) {
            return $matches[1] . ' ' . self::decline($matches[2], $case, $gender);
        }

        $words = preg_split('/\s+/', $position);
        $result = [];
        $i = 0;

        while ($i < count($words)) {
            $currentWord = $words[$i];
            if (empty($currentWord)) {
                $i++;
                continue;
            }

            // Фиксированные фразы
            $phraseFound = false;
            foreach (self::$fixedPhrases as $phrase) {
                $phraseWords = explode(' ', $phrase);
                if (self::arrayStartsWith($words, $i, $phraseWords)) {
                    $result[] = $phrase;
                    $i += count($phraseWords);
                    $phraseFound = true;
                    break;
                }
            }
            if ($phraseFound) continue;

            // Фиксированные слова
            if (in_array($currentWord, self::$fixedWords)) {
                $result[] = $currentWord;
                $i++;
                continue;
            }

            // Составные исключения
            if ($i + 1 < count($words)) {
                $twoWords = $currentWord . ' ' . $words[$i + 1];
                if (isset(self::$positionExceptions[$twoWords][$case])) {
                    $result[] = self::$positionExceptions[$twoWords][$case];
                    $i += 2;
                    continue;
                }
            }

            // Одиночные исключения
            if (isset(self::$positionExceptions[$currentWord][$case])) {
                $baseForm = self::findBaseForm($currentWord);
                $declined = self::$positionExceptions[$currentWord][$case];
                $result[] = $declined;

                // Управление: только в именительном
                if ($i + 1 < count($words) && $case === 'nominative' && $baseForm && isset(self::$governmentRules[$baseForm])) {
                    $nextWord = $words[$i + 1];
                    $requiredCase = self::$governmentRules[$baseForm];
                    $declinedNext = self::declineNounToCase($nextWord, $requiredCase);
                    $result[] = $declinedNext;
                    $i += 2;
                    continue;
                }

                $i++;
                continue; // ← ВАЖНО: дальше не идём!
            }

            // Обычное слово
            $declined = self::declineRegularWord($currentWord, $case, $gender);
            $result[] = $declined;

            // Управление для обычных слов (только в именительном)
            if ($i + 1 < count($words) && $case === 'nominative') {
                $baseForm = self::findBaseForm($currentWord);
                if ($baseForm && isset(self::$governmentRules[$baseForm])) {
                    array_pop($result);
                    $correctDeclined = self::declineRegularWord($currentWord, $case, $gender);
                    $result[] = $correctDeclined;

                    $nextWord = $words[$i + 1];
                    $requiredCase = self::$governmentRules[$baseForm];
                    $declinedNext = self::declineNounToCase($nextWord, $requiredCase);
                    $result[] = $declinedNext;
                    $i += 2;
                    continue;
                }
            }

            $i++;
        }

        return implode(' ', $result);
    }

    private static function arrayStartsWith($array, $start, $sequence)
    {
        if ($start + count($sequence) > count($array)) return false;
        for ($j = 0; $j < count($sequence); $j++) {
            if ($array[$start + $j] !== $sequence[$j]) return false;
        }
        return true;
    }

    private static function findBaseForm($word)
    {
        $forms = [
            'заведующий' => ['заведующий', 'заведующего', 'заведующему', 'заведующим', 'заведующем'],
            'заместитель' => ['заместитель', 'заместителя', 'заместителю', 'заместителем', 'заместителе'],
            'начальник' => ['начальник', 'начальника', 'начальнику', 'начальником', 'начальнике'],
            'директор' => ['директор', 'директора', 'директору', 'директором', 'директоре'],
            'министр' => ['министр', 'министра', 'министру', 'министром', 'министре'],
            'специалист' => ['специалист', 'специалиста', 'специалисту', 'специалистом', 'специалисте'],
            'инспектор' => ['инспектор', 'инспектора', 'инспектору', 'инспектором', 'инспекторе'],
            'консультант' => ['консультант', 'консультанта', 'консультанту', 'консультантом', 'консультанте'],
            'советник' => ['советник', 'советника', 'советнику', 'советником', 'советнике'],
            'губернатор' => ['губернатор', 'губернатора', 'губернатору', 'губернатором', 'губернаторе'],
        ];

        foreach ($forms as $base => $formList) {
            if (in_array($word, $formList)) {
                return $base;
            }
        }
        return null;
    }

    private static function declineRegularWord($word, $case, $gender)
    {
        if (self::isAdjective($word)) {
            return self::declineAdjective($word, $case, $gender);
        }
        if (self::isNoun($word)) {
            return self::declineNoun($word, $case);
        }
        return $word;
    }

    private static function declineNounToCase($word, $targetCase)
    {
        $lastChar = mb_substr($word, -1, 1, 'UTF-8');

        switch ($targetCase) {
            case 'instrumental':
                if (preg_match('/[бвгджзйклмнпрстфхцчшщ]$/u', $lastChar)) {
                    return $word . 'ом';
                }
                if ($lastChar === 'о' || $lastChar === 'е') {
                    return mb_substr($word, 0, -1, 'UTF-8') . 'м';
                }
                if ($lastChar === 'а') {
                    return mb_substr($word, 0, -1, 'UTF-8') . 'ой';
                }
                if ($lastChar === 'я') {
                    return mb_substr($word, 0, -1, 'UTF-8') . 'ей';
                }
                break;

            case 'genitive':
                if (preg_match('/[бвгджзйклмнпрстфхцчшщ]$/u', $lastChar)) {
                    return $word . 'а';
                }
                if ($lastChar === 'о' || $lastChar === 'е') {
                    return mb_substr($word, 0, -1, 'UTF-8') . 'а';
                }
                if ($lastChar === 'а') {
                    return mb_substr($word, 0, -1, 'UTF-8') . 'ы';
                }
                if ($lastChar === 'я') {
                    return mb_substr($word, 0, -1, 'UTF-8') . 'и';
                }
                break;
        }

        return $word;
    }

    private static function isAdjective($word)
    {
        $endings = ['ый', 'ий', 'ой', 'ая', 'яя', 'ое', 'ее', 'ые', 'ие'];
        foreach ($endings as $ending) {
            if (mb_substr($word, -mb_strlen($ending), null, 'UTF-8') === $ending) {
                return true;
            }
        }
        return false;
    }

    private static function isNoun($word)
    {
        return !self::isAdjective($word) && !in_array($word, self::$fixedWords) && mb_strlen($word) > 1;
    }

    private static function declineAdjective($word, $case, $gender)
    {
        $endings = [
            'male' => [
                'ый' => ['genitive' => 'ого', 'dative' => 'ому', 'accusative' => 'ого', 'instrumental' => 'ым', 'prepositional' => 'ом'],
                'ий' => ['genitive' => 'его', 'dative' => 'ему', 'accusative' => 'его', 'instrumental' => 'им', 'prepositional' => 'ем'],
                'ой' => ['genitive' => 'ого', 'dative' => 'ому', 'accusative' => 'ого', 'instrumental' => 'ым', 'prepositional' => 'ом']
            ],
            'female' => [
                'ая' => ['genitive' => 'ой', 'dative' => 'ой', 'accusative' => 'ую', 'instrumental' => 'ой', 'prepositional' => 'ой'],
                'яя' => ['genitive' => 'ей', 'dative' => 'ей', 'accusative' => 'юю', 'instrumental' => 'ей', 'prepositional' => 'ей']
            ],
            'neuter' => [
                'ое' => ['genitive' => 'ого', 'dative' => 'ому', 'accusative' => 'ое', 'instrumental' => 'ым', 'prepositional' => 'ом'],
                'ее' => ['genitive' => 'его', 'dative' => 'ему', 'accusative' => 'ее', 'instrumental' => 'им', 'prepositional' => 'ем']
            ]
        ];

        foreach ($endings[$gender] ?? [] as $ending => $cases) {
            if (mb_substr($word, -mb_strlen($ending), null, 'UTF-8') === $ending) {
                $base = mb_substr($word, 0, -mb_strlen($ending), 'UTF-8');
                return $base . ($cases[$case] ?? $ending);
            }
        }

        return $word;
    }

    private static function declineNoun($word, $case)
    {
        if ($case === 'nominative') return $word;

        // Исключения
        foreach (self::$positionExceptions as $base => $forms) {
            if (!str_contains($base, ' ') && $word === $base) {
                return $forms[$case] ?? $word;
            }
        }

        $lastChar = mb_substr($word, -1, 1, 'UTF-8');

        // Мужской род на согласную
        if (preg_match('/[бвгджзйклмнпрстфхцчшщ]$/u', $lastChar)) {
            $map = [
                'genitive' => 'а',
                'dative' => 'у',
                'accusative' => $word,
                'instrumental' => 'ом',
                'prepositional' => 'е'
            ];
            return $word . ($map[$case] ?? '');
        }

        // На -о, -е
        if (in_array($lastChar, ['о', 'е'])) {
            $base = mb_substr($word, 0, -1, 'UTF-8');
            $map = [
                'genitive' => 'а',
                'dative' => 'у',
                'accusative' => $word,
                'instrumental' => 'м',
                'prepositional' => 'е'
            ];
            return $base . ($map[$case] ?? '');
        }

        // Женский род на -а
        if ($lastChar === 'а') {
            $base = mb_substr($word, 0, -1, 'UTF-8');
            $map = [
                'genitive' => 'ы',
                'dative' => 'е',
                'accusative' => 'у',
                'instrumental' => 'ой',
                'prepositional' => 'е'
            ];
            return $base . ($map[$case] ?? '');
        }

        // Женский род на -я
        if ($lastChar === 'я') {
            $base = mb_substr($word, 0, -1, 'UTF-8');
            $map = [
                'genitive' => 'и',
                'dative' => 'е',
                'accusative' => 'ю',
                'instrumental' => 'ей',
                'prepositional' => 'е'
            ];
            return $base . ($map[$case] ?? '');
        }

        return $word;
    }
}
/*
// ТЕСТИРОВАНИЕ
echo "=== ТЕСТИРОВАНИЕ ИСПРАВЛЕННОЙ ВЕРСИИ ===\n\n";

$testCases = [
    'Заместитель заведующего отделом финансового контроля',
    'Главный инспектор',
    'Главный специалист отдела обеспечения контрольных функций',
    'ВРИО Губернатора',
    'Первый заместитель министра социального развития',
    'Заместитель директора'
];

foreach ($testCases as $position) {
    echo "Исходное:        $position\n";
    echo 'Родительный:     ' . PositionDeclension::decline($position, 'genitive') . "\n";
    echo 'Дательный:       ' . PositionDeclension::decline($position, 'dative') . "\n";
    echo 'Творительный:    ' . PositionDeclension::decline($position, 'instrumental') . "\n";
    echo str_repeat('-', 80) . "\n";
}*/
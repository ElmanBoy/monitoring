<html>
<head>
	<title>{$maintitle}</title>
			<link rel="stylesheet" href="{$subdir}media/stylesheet.css" />
			<meta http-equiv='Content-Type' content='text/html; charset={$charset}'/>
</head>
<body>
<div align="center"><h1>{$maintitle}</h1></div>
<b>Welcome to {$package}!</b><br />
<br />
© Copyright by <a href="http://moguta.ru">Moguta.CMS</a><br />
</body>
</html>

{include file="header.tpl" top3=true}

<h2 class="file-name"><img src="{$subdir}media/images/Page_logo.png" alt="File" style="vertical-align: middle">{$source_location}</h2>

<a name="sec-description"></a>
<div class="info-box">
	<div class="info-box-title">Описание</div>
	<div class="nav-bar">
		{if $classes || $includes || $defines || $globals || $functions}
			<span class="disabled">Описание</span> |
		{/if}
		{if $classes}
			<a href="#sec-classes">Классы</a>
			{if $includes || $defines || $globals || $functions}|{/if}
		{/if}
		{if $includes}
			<a href="#sec-includes">Содержит</a>
			{if $defines || $globals || $functions}|{/if}
		{/if}
		{if $defines}
			<a href="#sec-constants">Константы</a>
			{if $globals || $functions}|{/if}
		{/if}
		{if $globals}
			<a href="#sec-variables">Переменные</a>
			{if $functions}|{/if}
		{/if}
		{if $functions}
			<a href="#sec-functions">Функции</a>
		{/if}
	</div>
	<div class="info-box-body">	
		{include file="docblock.tpl" desc=$desc sdesc=$sdesc tags=$tags}
		
		{if $tutorial}
			<hr class="separator" />
			<div class="notes">Tutorial: <span class="tutorial">{$tutorial}</div>
		{/if}
	</div>
</div>
		
{if $classes}
	<a name="sec-classes"></a>	
	<div class="info-box">
		<div class="info-box-title">Классы</div>
		<div class="nav-bar">
			<a href="#sec-description">Описание</a> |
			<span class="disabled">Классы</span>
			{if $includes || $defines || $globals || $functions}|{/if}
			{if $includes}
				<a href="#sec-includes">Содержит</a>
				{if $defines || $globals || $functions}|{/if}
			{/if}
			{if $defines}
				<a href="#sec-constants">Константы</a>
				{if $globals || $functions}|{/if}
			{/if}
			{if $globals}
				<a href="#sec-variables">Переменные</a>
				{if $functions}|{/if}
			{/if}
			{if $functions}
				<a href="#sec-functions">Функции</a>
			{/if}
		</div>
		<div class="info-box-body">	
			<table cellpadding="2" cellspacing="0" class="class-table">
				<tr>
					<th class="class-table-header">Class</th>
					<th class="class-table-header">Описание</th>
				</tr>
				{section name=classes loop=$classes}
				<tr>
					<td style="padding-right: 2em; vertical-align: top; white-space: nowrap">
						<img src="{$subdir}media/images/{if $classes[classes].abstract}Abstract{/if}{if $classes[classes].access == 'private'}Private{/if}Class.png"
								 alt="{if $classes[classes].abstract}Abstract{/if}{if $classes[classes].access == 'private'}Private{/if} class"
								 title="{if $classes[classes].abstract}Abstract{/if}{if $classes[classes].access == 'private'}Private{/if} class"/>
						{$classes[classes].link}
					</td>
					<td>
					{if $classes[classes].sdesc}
						{$classes[classes].sdesc}
					{else}
						{$classes[classes].desc}
					{/if}
					</td>
				</tr>
				{/section}
			</table>
		</div>
	</div>
{/if}

{if $includes}
	<a name="sec-includes"></a>	
	<div class="info-box">
		<div class="info-box-title">Содержит</div>
		<div class="nav-bar">
			<a href="#sec-description">Описание</a> |
			{if $classes}
				<a href="#sec-classes">Классы</a>
				{if $includes || $defines || $globals || $functions}|{/if}
			{/if}
			<span class="disabled">Содержит</span>
			{if $defines || $globals || $functions}|{/if}
			{if $defines}
				<a href="#sec-constants">Константы</a>
				{if $globals || $functions}|{/if}
			{/if}
			{if $globals}
				<a href="#sec-variables">Переменные</a>
				{if $functions}|{/if}
			{/if}
			{if $functions}
				<a href="#sec-functions">Функции</a>
			{/if}
		</div>
		<div class="info-box-body">	
			{include file="include.tpl"}
		</div>
	</div>
{/if}
	
{if $defines}
	<a name="sec-constants"></a>	
	<div class="info-box">
		<div class="info-box-title">Константы</div>
		<div class="nav-bar">
			<a href="#sec-description">Описание</a> |
			{if $classes}
				<a href="#sec-classes">Классы</a>
				{if $includes || $defines || $globals || $functions}|{/if}
			{/if}
			{if $includes}
				<a href="#sec-includes">Содержит</a>
				{if $defines || $globals || $functions}|{/if}
			{/if}
			<span class="disabled">Константы</span>
			{if $globals || $functions}|{/if}
			{if $globals}
				<a href="#sec-variables">Переменные</a>
				{if $functions}|{/if}
			{/if}
			{if $functions}
				<a href="#sec-functions">Функции</a>
			{/if}
		</div>
		<div class="info-box-body">	
			{include file="define.tpl"}
		</div>
	</div>
{/if}
	
{if $globals}
	<a name="sec-variables"></a>	
	<div class="info-box">
		<div class="info-box-title">Переменные</div>
		<div class="nav-bar">
			<a href="#sec-description">Описание</a> |
			{if $classes}
				<a href="#sec-classes">Классы</a>
				{if $includes || $defines || $globals || $functions}|{/if}
			{/if}
			{if $includes}
				<a href="#sec-includes">Содержит</a>
				{if $defines || $globals || $functions}|{/if}
			{/if}
			{if $defines}
				<a href="#sec-constants">Константы</a>
				{if $globals || $functions}|{/if}
			{/if}
			<span class="disabled">Переменные</span>
			{if $functions}|{/if}
			{if $functions}
				<a href="#sec-functions">Функции</a>
			{/if}
		</div>
		<div class="info-box-body">	
			{include file="global.tpl"}
		</div>
	</div>
{/if}
	
{if $functions}
	<a name="sec-functions"></a>	
	<div class="info-box">
		<div class="info-box-title">Функции</div>
		<div class="nav-bar">
			<a href="#sec-description">Описание</a> |
			{if $classes}
				<a href="#sec-classes">Классы</a>
				{if $includes || $defines || $globals || $functions}|{/if}
			{/if}
			{if $includes}
				<a href="#sec-includes">Содержит</a>
				{if $defines || $globals || $functions}|{/if}
			{/if}
			{if $defines}
				<a href="#sec-constants">Константы</a>
				{if $globals || $functions}|{/if}
			{/if}
			{if $globals}
				<a href="#sec-variables">Переменные</a>
				{if $functions}|{/if}
			{/if}
			<span class="disabled">Функции</span>
		</div>
		<div class="info-box-body">	
			{include file="function.tpl"}
		</div>
	</div>
{/if}
	
{include file="footer.tpl" top3=true}

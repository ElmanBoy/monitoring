{capture name="tutle"}Файл источник для {$name}{/capture}
{include file="header.tpl" title=$smarty.capture.tutle}
<h1>Источник дляфайла {$name}</h1>
<p>Документация доступна на{$docs}</p>
<div class="src-code">
{$source}
</div>
{include file="footer.tpl"}
{if !$index}
	<p class="notes" id="credit">
		© Copyright by <a href="http://moguta.ru">Moguta.CMS</a><br />
	</p>
{/if}
	{if $top3}</div>{/if}	
</body>
</html>

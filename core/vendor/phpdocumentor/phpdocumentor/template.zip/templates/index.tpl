<?xml version="1.0" encoding="{$charset}"?>
<!DOCTYPE html 
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//FR"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
   <html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- Документация создана {$date}  -->
  <title>{$title}</title>
  <meta http-equiv='Content-Type' content='text/html; charset={$charset}'/>
</head>

<FRAMESET rows='120,*'>
	<FRAME src='packages.html' name='left_top' frameborder="1" bordercolor="#999999">
	<FRAMESET cols='25%,*'>
		<FRAME src='{$start}' name='left_bottom' frameborder="1" bordercolor="#999999">
		<FRAME src='{$blank}.html' name='right' frameborder="1" bordercolor="#999999">
	</FRAMESET>
	<NOFRAMES>
		<H2>Оповещение</H2>
		<P>Документация использует фрэймы. Если вы видите это сообщение, значит ваш браузер не поддерживает фреймы.</P>
	</NOFRAMES>
</FRAMESET>
</HTML>
